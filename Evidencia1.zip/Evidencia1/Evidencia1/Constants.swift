//
//  Constants.swift
//  Evidencia1
//
//  Created by David Saucedo on 07/05/21.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
     
    }
    
    
}
